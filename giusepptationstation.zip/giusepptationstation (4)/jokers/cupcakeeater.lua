
SMODS.Joker{ --Cupcake Eater
    key = "cupcakeeater",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Cupcake Eater',
        ['text'] = {
            [1] = 'If the first scored card is a {C:hearts}Heart{} and the rest are {C:diamonds}Diamonds{},',
            [2] = '{X:red,C:white}x4 {} Mult and {X:money,C:white}+$5{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["giuseppt_giuseppt_jokers"] = true }
}