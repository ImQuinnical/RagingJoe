
SMODS.Joker{ --Hotdog Eating Contest
    key = "hotdogeatingcontest",
    config = {
        extra = {
            emult0 = 2,
            mult0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Hotdog Eating Contest',
        ['text'] = {
            [1] = '{C:red}+1{} Mult',
            [2] = 'If paired with Straight Teeth:',
            [3] = '{X:red,C:white}Mult^2{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 0,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["giuseppt_giuseppt_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_giuseppt_straightteeth" then 
                        return true
                    end
                end
            end)() then
                return {
                    e_mult = 2
                }
            else
                return {
                    mult = 1
                }
            end
        end
    end
}