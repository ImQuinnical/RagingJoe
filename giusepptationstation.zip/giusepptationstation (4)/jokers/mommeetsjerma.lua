
SMODS.Joker{ --Mom Meets Jerma
    key = "mommeetsjerma",
    config = {
        extra = {
            odds = 10,
            xchips0 = 0,
            xmult0 = 0,
            xmult = 4,
            xchips = 4
        }
    },
    loc_txt = {
        ['name'] = 'Mom Meets Jerma',
        ['text'] = {
            [1] = '{X:red,C:white}X4{} Mult and {X:blue,C:white}X4{} Chips. {C:edition}1 in 100{} chance to lose immediately.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["giuseppt_giuseppt_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_giuseppt_mommeetsjerma') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                local destructable_jokers = {}
                for i, joker in ipairs(G.jokers.cards) do
                    if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                        table.insert(destructable_jokers, joker)
                    end
                end
                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
                if SMODS.pseudorandom_probability(card, 'group_0_a1f5cdfa', 1, card.ability.extra.odds, 'j_giuseppt_mommeetsjerma', false) then
                    SMODS.calculate_effect({x_chips = 0}, card)
                    SMODS.calculate_effect({Xmult = 0}, card)
                end
            else
                return {
                    Xmult = 4,
                    extra = {
                        x_chips = 4,
                        colour = G.C.DARK_EDITION
                    }
                }
            end
        end
    end
}