
SMODS.Joker{ --Ozempic Victim
    key = "ozempicvictim",
    config = {
        extra = {
            multCounter = 1
        }
    },
    loc_txt = {
        ['name'] = 'Ozempic Victim',
        ['text'] = {
            [1] = '{C:dark_edition}Ozempic {}took THIS man\'s life.',
            [2] = 'Gains {X:red,C:white}1X Mult{} for each Judgement Card used.',
            [3] = '(Currently {X:red,C:white}#1#X{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["giuseppt_giuseppt_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multCounter}}
    end,
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Tarot' and context.consumeable.config.center.key == 'c_judgement' then
                return {
                    func = function()
                        card.ability.extra.multCounter = (card.ability.extra.multCounter) + 1
                        return true
                    end,
                    message = "Lawsuit!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multCounter
            }
        end
    end
}