
SMODS.Joker{ --Pico Park With Joe
    key = "picoparkwithjoe",
    config = {
        extra = {
            xchips0 = 1.5,
            xchips = 0.5
        }
    },
    loc_txt = {
        ['name'] = 'Pico Park With Joe',
        ['text'] = {
            [1] = 'Balance Chips and Mult',
            [2] = '{X:blue,C:white}x0.5{} Chips for each odd card scored',
            [3] = '{X:chips,C:white}X1.5{} Chips for each even card scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["giuseppt_giuseppt_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) then
                return {
                    x_chips = 1.5
                }
            elseif (context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9) then
                return {
                    x_chips = 0.5
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                balance = true
            }
        end
    end
}