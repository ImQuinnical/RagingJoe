
SMODS.Joker{ --Nipple Goblin
    key = "nipplegoblin",
    config = {
        extra = {
            moneyStolen = 0,
            dollars0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Nipple Goblin',
        ['text'] = {
            [1] = 'He wants your money.',
            [2] = 'He currently wants it{C:red} #1# {} times as much as you do.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["giuseppt_giuseppt_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.moneyStolen}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.moneyStolen = (card.ability.extra.moneyStolen) + 1
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars - 2
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(2), colour = G.C.MONEY})
                    return true
                end,
                extra = {
                    mult = card.ability.extra.moneyStolen
                }
            }
        end
    end
}