
SMODS.Joker{ --Straight Teeth
    key = "straightteeth",
    config = {
        extra = {
            echips0 = 2,
            chips0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Straight Teeth',
        ['text'] = {
            [1] = '{C:blue}+1{} Chip',
            [2] = 'If paired with Hotdog Eating Contest,',
            [3] = '{C:blue}Chips^2{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 0,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["giuseppt_giuseppt_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_giuseppt_hotdogeatingcontest" then 
                        return true
                    end
                end
            end)() then
                return {
                    e_chips = 2
                }
            else
                return {
                    chips = 1
                }
            end
        end
    end
}