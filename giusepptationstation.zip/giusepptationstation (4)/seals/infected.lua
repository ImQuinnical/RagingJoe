
SMODS.Seal {
    key = 'infected',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xchips0 = 0,
            xmult0 = 2
        }
    },
    badge_colour = HEX('077407'),
    loc_txt = {
        name = 'Infected',
        label = 'Infected',
        text = {
            [1] = 'When scored resets Chips to {C:blue}0{}.',
            [2] = 'However, {X:red,C:white}doubles{} Mult.'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                x_chips = 0,
                extra = {
                    Xmult = 2
                }
            }
        end
    end
}