
SMODS.Booster {
    key = 'gooniseppes_mystery_pack',
    loc_txt = {
        name = "Gooniseppe's Mystery Pack",
        text = {
            [1] = 'These cards are cards,,'
        },
        group_name = "giuseppt_boosters"
    },
    config = { extra = 3, choose = 1 },
    cost = 8,
    weight = 2,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "giuseppt_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            1,
            1,
            1,
            1,
            1,
            1,
            0.15,
            1.5,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('giuseppt_gooniseppes_mystery_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
                key = "j_giuseppt_mommeetsjerma",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 2 then
            return {
                key = "j_giuseppt_picoparkwithjoe",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 3 then
            return {
                key = "j_giuseppt_ozempicvictim",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 4 then
            return {
                key = "j_giuseppt_joeisanalien",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 5 then
            return {
                key = "j_giuseppt_subduralhematoma",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 6 then
            return {
                key = "j_giuseppt_nipplegoblin",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 7 then
            return {
                key = "j_giuseppt_hotdogeatingcontest",
                set = "giuseppt_giuseppt_hotdogeatingcontest",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 8 then
            return {
                key = "j_giuseppt_straightteeth",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        elseif selected_index == 9 then
            return {
                key = "j_giuseppt_cupcakeeater",
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "giuseppt_gooniseppes_mystery_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("b67f7f"))
        ease_background_colour({ new_colour = HEX('b67f7f'), special_colour = HEX("dc0000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    