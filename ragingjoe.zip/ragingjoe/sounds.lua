SMODS.Sound{
    key="joe_screaming",
    path="joe_screaming.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_scared",
    path="joe_scared.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_banned",
    path="joe_banned.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_seventwitchaccounts",
    path="joe_seventwitchaccounts.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_crying",
    path="joe_crying.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_getoverit",
    path="joe_getoverit.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_donewiththis",
    path="joe_donewiththis.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_no",
    path="joe_no.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_scrum",
    path="joe_scrum.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_screamingmore",
    path="joe_screamingmore.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_shushagain",
    path="joe_shushagain.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_shutup",
    path="joe_shutup.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_STFU",
    path="joe_STFU.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_idiot",
    path="joe_idiot.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_family",
    path="joe_family.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="joe_passesout",
    path="joe_passesout.ogg",
    pitch=0.7,
    volume=0.6,
}