SMODS.Joker{
    key = "ragingjoe",

    config = {
        extra = {
            retriggers = 0,
            odds = 25, -- TESTING: 1 in 2 (set back to 25 later)
            passedout_pending = false,
            scared_handle = nil
        }
    },

    loc_txt = {
        name = "Raging Joe",
        text = {
            "{C:red}Destroys{} all Jokers to the left",
            "{C:clubs}Retriggers{} first played card for each card destroyed",
            "(Currently: {C:blue}#1#{})"
        }
    },

    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.retriggers or 0 } }
    end,

    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },

    cost = 6,
    rarity = 3,

    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

    unlocked = true,
    discovered = true,

    atlas = "CustomJokers",
    pools = { ["ragingjo_mycustom_jokers"] = true },

    calculate = function(self, card, context)

        ----------------------------------------------------------------------
        -- Helpers
        ----------------------------------------------------------------------
        local function mod_prefix()
            return (RAGINGJOE_PREFIX or (SMODS.current_mod and SMODS.current_mod.prefix) or "")
        end

        local function play_joe_sound(key_without_prefix, pitch, volume)
            return play_sound(mod_prefix() .. "_" .. key_without_prefix, pitch, volume)
        end

        local function stop_scared_sound()
            local h = card.ability.extra.scared_handle
            if h then
                pcall(function()
                    if type(h) == "table" and h.stop then h:stop() end
                end)
            end
            card.ability.extra.scared_handle = nil

            -- fallback: hard stop all audio so joe_scared never bleeds into shop
            pcall(function()
                if love and love.audio and love.audio.stop then
                    love.audio.stop()
                end
            end)
        end

        local function safe_eternal_vfx()
            -- Safe effects that will never delete the card
            card:juice_up(2.0, 0.6)

            pcall(function()
                if card.flash then card:flash() end
            end)

            pcall(function()
                card_eval_status_text(card, "extra", nil, nil, nil, {
                    message = "!!!",
                    colour = G.C.RED
                })
            end)
        end

        ----------------------------------------------------------------------
        -- DESTROY JOKERS TO THE LEFT (REAL CARD ONLY, ONCE PER HAND)
        ----------------------------------------------------------------------
        if context.before and context.cardarea == G.jokers and not context.blueprint then
            local my_pos
            for i = 1, #G.jokers.cards do
                if G.jokers.cards[i] == card then
                    my_pos = i
                    break
                end
            end

            if my_pos and my_pos > 1 then
                local destroyed = 0

                -- Play ONE random sound per hand (1..14)
                local sound_id = pseudorandom("ragingjoe_sound", 1, 14)
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_joe_sound("joe_" .. tostring(sound_id))
                        return true
                    end
                }))

                -- Destroy ALL jokers to the left
                for i = my_pos - 1, 1, -1 do
                    local j = G.jokers.cards[i]
                    if j and not j.getting_sliced then
                        destroyed = destroyed + 1
                        j.getting_sliced = true

                        -- your chosen behavior: remove eternal then destroy
                        if j.ability.eternal then
                            j.ability.eternal = nil
                        end

                        G.E_MANAGER:add_event(Event({
                            func = function()
                                j:explode({G.C.RED}, nil, 1.6)
                                return true
                            end
                        }))
                    end
                end

                if destroyed > 0 then
                    card.ability.extra.retriggers =
                        (card.ability.extra.retriggers or 0) + destroyed

                    card_eval_status_text(card, "extra", nil, nil, nil, {
                        message = "+" .. destroyed,
                        colour = G.C.CLUBS
                    })
                end
            end
        end

        ----------------------------------------------------------------------
        -- PERMANENT RETRIGGERS (FIRST PLAYED CARD)
        ----------------------------------------------------------------------
        if context.repetition
        and context.cardarea == G.play
        and (card.ability.extra.retriggers or 0) > 0 then

            local first_played = context.full_hand and context.full_hand[1]
            if first_played and context.other_card == first_played then
                return { repetitions = card.ability.extra.retriggers }
            end
        end

        ----------------------------------------------------------------------
        -- END OF ROUND PROC (REAL ONLY)
        -- Always: joe_scared + juice
        -- Non-eternal: explode + die
        -- Eternal: survive + safe VFX + queue passesout
        ----------------------------------------------------------------------
        if context.end_of_round
        and context.main_eval
        and not context.game_over
        and not context.blueprint then

            if SMODS.pseudorandom_probability(card, "ragingjoe_death", 1, card.ability.extra.odds) then

                -- play scared, store handle if any
                G.E_MANAGER:add_event(Event({
                    func = function()
                        card.ability.extra.scared_handle = play_joe_sound("joe_scared")
                        return true
                    end
                }))

                if card.ability and card.ability.eternal then
                    card.ability.extra.passedout_pending = true

                    -- Eternal-safe: shake/juice/flash ONLY
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            safe_eternal_vfx()
                            return true
                        end
                    }))
                else
                    -- Non-eternal: shake/juice then explode + die
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            card:juice_up(2.0, 0.6)
                            return true
                        end
                    }))

                    G.E_MANAGER:add_event(Event({
                        trigger = "after",
                        delay = 0.15,
                        func = function()
                            card.getting_sliced = true
                            card:explode({G.C.RED}, nil, 1.8)
                            return true
                        end
                    }))
                end
            end
        end

        ----------------------------------------------------------------------
        -- NEXT SHOP: CUT OFF SCARED SOUND, THEN PLAY PASSESOUT (REAL ONLY)
        ----------------------------------------------------------------------
        if context.starting_shop
        and not context.blueprint
        and card.ability.extra.passedout_pending then

            card.ability.extra.passedout_pending = false
            stop_scared_sound()

            G.E_MANAGER:add_event(Event({
                func = function()
                    play_joe_sound("joe_passesout")
                    return true
                end
            }))
        end
    end
}
