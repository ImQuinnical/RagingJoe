-- =========================
-- ATLASES
-- =========================

SMODS.Atlas({
    key = "modicon",
    path = "ModIcon.png",
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro",
    path = "balatro.png",
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomJokers",
    path = "CustomJokers.png",
    px = 71,
    py = 95,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks",
    path = "CustomDecks.png",
    px = 71,
    py = 95,
    atlas_table = "ASSET_ATLAS"
})

-- =========================
-- RAGING JOE SOUNDS (REGISTER ONCE)
-- =========================

for i = 1, 14 do
    SMODS.Sound{
        key = "joe_" .. i,
        path = "joe_" .. i .. ".ogg"
    }
end

SMODS.Sound{
    key = "joe_scared",
    path = "joe_scared.ogg"
}

SMODS.Sound{ key = "joe_passesout", path = "joe_passesout.ogg" }

-- =========================
-- HELPERS
-- =========================

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end


RAGINGJOE_PREFIX = SMODS.current_mod.prefix

-- =========================
-- LOAD JOKERS
-- =========================

local jokerIndexList = { 1 }

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)

    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end

-- =========================
-- LOAD DECKS
-- =========================

local deckIndexList = { 1 }

local function load_decks_folder()
    local mod_path = SMODS.current_mod.path
    local decks_path = mod_path .. "/decks"
    local files = NFS.getDirectoryItemsInfo(decks_path)

    for i = 1, #deckIndexList do
        local file_name = files[deckIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("decks/" .. file_name))()
        end
    end
end

-- =========================
-- LOAD CONTENT
-- =========================

load_jokers_folder()
load_decks_folder()

-- =========================
-- OBJECT TYPES
-- =========================

SMODS.ObjectType({
    key = "ragingjo_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    }
})

SMODS.ObjectType({
    key = "ragingjo_mycustom_jokers",
    cards = {
        ["j_ragingjo_ragingjoe"] = true
    }
})

-- =========================
-- OPTIONAL FEATURES
-- =========================

SMODS.current_mod.optional_features = function()
    return {
        cardareas = {}
    }
end
